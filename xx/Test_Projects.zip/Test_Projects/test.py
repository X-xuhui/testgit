# class Solution(object):
#     def fib(self, n):
#         pre,after = 0,1
#         for i in range(n):
#             pre,after = after,pre+after
#         print pre % 1000000007
# a= Solution()
# a.fib(5)

# s = "loveleetcode"

# for i in range(len(s)):
#     if s[i] not in s[i+1:len(s)] and s[i] not in s[:i]:
#         print s[i]
# print ' '

# dic = {}
# for c in s:
#     dic[c] = not c in dic
# for c in s:
#     if dic[c]: print c
# print ' '

# prices = [7,1,5,3,6,4]
# revenue = 0
# Min = prices[0]
# for i in range(1,len(prices)):
#     revenue = max(revenue,prices[i]-Min)
#     Min = min(Min,prices[i])
# print revenue

# a,b = 1,3
# x = 0xffffffff
# a, b = a & x, b & x
# while b != 0:
#     a, b = (a ^ b), (a & b) << 1 & x
# print a if a <= 0x7fffffff else ~(a ^ x)

# nums = [2,2,3,4]
# slow = fast = 0
# while fast < len(nums):
#     if nums[fast] % 2 == 1:
#         nums[slow], nums[fast] = nums[fast], nums[slow]
#         slow += 1
#     fast += 1
# print nums

# nums = [10,26,30,31,47,60]
# target = 40
# left,right = 0,len(nums)-1
# while nums:
#     while right > left:
#         if nums[left]+nums[right] == target:
#             print nums[left],nums[right]
#         right -= 1
#     right = len(nums)-1
#     left += 1
# print None

# s = 'the sky is blue'
# s = s.strip()
# i = j = len(s) - 1
# res = []
# while i >= 0:
#     while i >= 0 and s[i] != ' ': i -= 1
#     res.append(s[i + 1: j + 1])
#     while s[i] == ' ': i -= 1
#     j = i
# print(''.join(res))

# a = [1,2,3,4,5]
# b, tmp = [1] * len(a), 1
# for i in range(1,len(a)):
#     b[i] = b[i-1] * a[i-1]
# for j in range(len(a) - 2, -1, -1):
#     tmp *= a[j+1]
#     b[j] *= tmp
# print(b)

# n = 8
# dp = [0 for i in range(n + 1)]
# for i in range(2, n + 1):
#     cur_max = 0
#     for j in range(1, i):
#         cur_max = max(cur_max, max(j * (i - j), j * dp[i - j]))
#     dp[i] = cur_max
# print(dp[n])


# names = ['关羽', '张飞', '赵云', '马超', '黄忠']
# courses = ['语文', '数学', '英语']
# scores = [[None] * len(courses) for _ in range(len(names))]
# # scores = [[None] * len(courses)] * len(names)  因为指向同一内存单元所以一个值改变其它都会改变
# for row, name in enumerate(names):
#     for col, course in enumerate(courses):
#         scores[row][col] = float(input(f'请输入{name}的{course}成绩: '))
#         print(scores)

# import heapq  #堆排序，寻找可迭代对象中n个符合条件的元素
#
# list1 = [34, 25, 12, 99, 87, 63, 58, 78, 88, 92]
# list2 = [
#     {'name': 'IBM', 'shares': 100, 'price': 91.1},
#     {'name': 'AAPL', 'shares': 50, 'price': 543.22},
#     {'name': 'FB', 'shares': 200, 'price': 21.09},
#     {'name': 'HPQ', 'shares': 35, 'price': 31.75},
#     {'name': 'YHOO', 'shares': 45, 'price': 16.35},
#     {'name': 'ACME', 'shares': 75, 'price': 115.65}
# ]
# print(heapq.nlargest(3, list1))
# print(heapq.nsmallest(3, list1))
# print(heapq.nlargest(2, list2, key=lambda x: x['price']))
# print(heapq.nlargest(2, list2, key=lambda x: x['shares']))


# import itertools
#
# ele = [  # 产生ABCD的全排列
#     itertools.permutations('ABCD'),
#     # 产生ABCDE的五选三组合
#     itertools.combinations('ABCDE', 3),
#     # 产生ABCD和123的笛卡尔积
#     itertools.product('ABCD', '123')]
# for x in ele:
#     print(list(x))

# from collections import Counter, deque, defaultdict

# words = [
#     'look', 'into', 'my', 'eyes', 'look', 'into', 'my', 'eyes',
#     'the', 'eyes', 'the', 'eyes', 'the', 'eyes', 'not', 'around',
#     'the', 'eyes', "don't", 'look', 'around', 'the', 'eyes',
#     'look', 'into', 'my', 'eyes', "you're", 'under'
# ]
# counter = Counter(words)
# print(counter.most_common(3))

# q = deque(['a','a','b','c'],maxlen=10)
# q.count('a')  #计算元素出现次数
# q.extend(['1','2','3'])
# q.index('c',1,4) #在指定开始与结束之间查找元素
# q.insert(0,'aa')
# q.rotate() #移位操作，默认n=1向右移位-1则向左移位
# print(q)

# d = defaultdict(list)
# s = [('aa', 1), ('bb', 2), ('aa', 2)]
# for k, v in s:
#     d[k].append(v)  # d[k] = v 形式：{'dd':33}如果再有重复键时则会将已有值替换，而使用append则是将重复键值加入列表
# print(d)  # defaultdict(<class 'list'>, {'aa': [1, 2], 'bb': [2]})
# 实现与以上相同结果
# d = {}
# s = [('aa', 1), ('bb', 2), ('aa', 2)]
# for k, v in s:
#     d.setdefault(k, []).append(v)

# s = 'mioasdjaoig'
# d = defaultdict(int)  # 实现对重复元素的计算,等同于Counter（）
# for k in s:
#     d[k] += 1
# print(d)  # defaultdict(<class 'int'>, {'m': 1, 'i': 2, 'o': 2, 'a': 2, 's': 1, 'd': 1, 'j': 1, 'g': 1})

import datetime

# from openpyxl import Workbook,load_workbook
#
# # wb = Workbook()
# # sheet1 = wb.active
# # wb.create_sheet('sheet2')
# # sheet1.append(['name','age','class'])
# # print(wb.sheetnames)
# # wb.active = 1
# # sheet2 = wb.active
# # print(wb.active)
# # wb.save(r'./pro/testxl.xlsx')
#
# ws = load_workbook(r'./pro/testxl.xlsx')
# def get_data(sheet):
#     for row in sheet.rows:
#         for cell in row:
#             print(cell.value)
# sheet1 = ws['Sheet']
# get_data(sheet1)
# sheet2 = ws.active
# # sheet2.append(['吕布','张飞','关羽'])
# get_data(sheet2)
# # ws.save(r'./pro/testxl.xlsx')

# 有四个数字：1、2、3、4，能组成多少个互不相同且无重复数字的三位数？各是多少？
import itertools
#
# print(list(itertools.permutations(range(1, 5), 3)))
# for i in range(1, 5):
#     for j in range(1, 5):
#         for k in range(1, 5):
#             if i != j and i != k and j != k:
#                 print(i, j, k)

# 企业发放的奖金根据利润提成。
# 利润(I)低于或等于10万元时，奖金可提10 %；利润高于10万元，低于20万元时，低于10万元的部分按10 % 提成，高于10万元的部分，可提成7.5 %；
# 20万到40万之间时，高于20万元的部分，可提成5 %；
# 40万到60万之间时高于40万元的部分，可提成3 %；
# 60万到100万之间时，高于60万元的部分，可提成1.5 %，高于100万元时，超过100万元的部分按1 % 提成，从键盘输入当月利润I，求应发放奖金总数？

# I = int(input('Profit is:'))
# prize = 0
# money = [1000000,600000,400000,200000,100000,0]
# rate = [0.01,0.15,0.03,0.05,0.075,0.1]
# for i in range(6):
#     if I > money[i]:
#         prize += (I - money[i])*rate[i]
#         I = money[i]
# print('Actual prize is:',prize)

# 一个整数，它加上100后是一个完全平方数，再加上168又是一个完全平方数，请问该数是多少？

# for i in range(1, 85):
#     if 168 % i == 0:
#         j = 168 / i
#         if i > j and (i + j) % 2 == 0 and (i - j) % 2 == 0:
#             m = (i + j) / 2
#             n = (i - j) / 2
#             x = n * n - 100
#             print(x)

# 输入某年某月某日，判断这一天是这一年的第几天？
import functools
import math
import random
import sys

#
# months = [31,28,31,30,31,30,31,31,30,31,30,31]
# date = sys.stdin.readline().split()
# year,month,day = map(int,date)
# if 0 < month <= 12:
#     if (year % 400 == 0) or ((year % 4 == 0) and (year % 100 != 0)):
#         months[1] += 1
#     if day <= months[month-1]:
#         days = sum(months[:month]) - (months[month - 1] - day)
#         print(f'Today is the {days} day of {year}!')

# 输入三个整数x,y,z，请把这三个数由小到大输出。
# x, y, z = map(int, sys.stdin.readline().split())
# if x > y:
#     x, y = y, x
# if x > z:
#     x, z = z, x
# if y > z:
#     y, z = z, y
# print(x, y, z)

# 输出 9*9 乘法口诀表
# for row in range(1,10):
#     for col in range(1,row+1):
#         print(f'{col} * {row} = {row * col}',end='\t')
#     print(end='\n')

# 时间函数的使用
import time, calendar, datetime

#
# print(time.strftime('%Y-%m-%d %H:%M:%S (%a,%A) (%b,%B) (%c) (%I) (%p)', time.localtime()))
# print(time.localtime(time.time()))
# print(time.ctime())
# # print(time.asctime((2020, 12, 3, 11, 3, 3, 0, 211, 0)))  # 年 月 日 时 分 秒 星期 天数 夏令时
# print(time.gmtime())
# print(time.strptime('2022-10-13 16:48:27', '%Y-%m-%d %H:%M:%S'))
# print(time.timezone)
# print(time.tzname)

# print(calendar.calendar(2022, 2, 1, 6))
# print(calendar.isleap(2022))  # 判断是否闰年
# print(calendar.leapdays(2000, 2012))  # 判断期间闰年数
# print(calendar.month(2022, 10, 2, 1))
# print(calendar.monthcalendar(2022, 10))
# print(calendar.monthrange(2022, 10))
# print(calendar.weekday(2022, 10, 13))  # 返回指定日期的星期码下标

# print(datetime.date.today().strftime('%Y-%m-%d'))
# print(datetime.datetime.now().strftime('%H:%M:%S'))
# print(datetime.datetime.strptime('28 October, 2022', '%d %B, %Y'))
# print(datetime.date.fromtimestamp(12312159008))  # 从时间戳获取时间
# print(datetime.datetime.timestamp(datetime.datetime.now()))  # 从当前时间获取时间戳
# print(datetime.time(12, 56, 45, 123123))  # 时、分、秒、微秒
# t1 = datetime.datetime.today()
# t2 = datetime.datetime(2022, 10, 13, 10, 55, 45)
# print(t1 - t2)
# print(t2.replace(month=1 + t2.month))
# t3 = datetime.timedelta(weeks=2, days=5, hours=10, seconds=45)
# t4 = datetime.timedelta(weeks=2, days=3, hours=10, seconds=45)
# print(t3 - t4)

# 判断101-200之间有多少个素数，并输出所有素数

# length = 0
# for i in range(101,201):
#     count = 0
#     for j in range(1,i+1):
#         if i % j == 0:
#             count += 1
#     if count == 2:
#         print(i)
#         length += 1
# print(f'Have {length} prime number!')

# 打印出所有的"水仙花数"，所谓"水仙花数"是指一个三位数，其各位数字立方和等于该数本身。
# 例如：153是一个"水仙花数"，因为153 = 1的三次方＋5的三次方＋3的三次方

# for i in range(100, 1000):
#     h = i // 100
#     d = i // 10 % 10
#     g = i % 10
#     if i == h ** 3 + d ** 3 + g ** 3:
#         print(i)

# 将一个正整数分解质因数。例如：输入90,打印出90=2*3*3*5
# try:
#     prime_num = 2
#     prime_arr = []
#     num = int(input())
#     while True:
#         if num % prime_num == 0:
#             num //= prime_num
#         else:
#             prime_num += 1
#             if num == 1:
#                 break
#             continue
#         prime_arr.append(str(prime_num))
#     print('*'.join(prime_arr) if len(prime_arr) >= 2 else 'Not is a composite number!')
# except:
#     print('Please input an integer!')

# 输入一行字符，分别统计出其中英文字母、空格、数字和其它字符的个数
# s = input()
# char_dict = {}
# letter, space, digit, other = 0, 0, 0, 0
# for i in s:
#     if i.isalpha():
#         letter += 1
#     elif i.isspace():
#         space += 1
#     elif i.isdigit():
#         digit += 1
#     else:
#         other += 1
#     count = 0
#     if i not in char_dict:
#         char_dict[i] = count
#     for j in char_dict:
#         if i == j:
#             char_dict[i] = char_dict[i] + 1
# print(char_dict)
# print(f'letter:{letter},space:{space},digit:{digit},other:{other}')

# 求s=a+aa+aaa+aaaa+aa...a的值，其中a是一个数字。例如2+22+222+2222+22222(此时共有5个数相加)，几个数相加由键盘控制
# count = int(input())
# digit = input()
# formula = []
# for i in range(1, count + 1):
#     formula.append(int(f'{digit}' * i))
# print(sum(formula))

# 一个数如果恰好等于它的因子之和，这个数就称为"完数"。例如6=1＋2＋3.编程找出1000以内的所有完数

# for i in range(1,1001):
#     summary = 0
#     for j in range(1,i):
#         if i % j == 0:
#             summary += j
#     if summary == i:
#         print(i)

# 一球从100米高度自由落下，每次落地后反跳回原高度的一半；再落下，求它在第10次落地时，共经过多少米？第10次反弹多高？
# height = 100
# meter = 0
# bound = []
# for i in range(10):
#     if i < 9:
#         meter += 2 * (height * 0.5)
#     height = height * 0.5
#     bound.append(height)
# meter += 100
# print('第十次弹起高度为:%.2f' % bound[-1])
# print('共经过%.2f米' % meter)

# 猴子吃桃问题：猴子第一天摘下若干个桃子，当即吃了一半，还不瘾，又多吃了一个第二天早上又将剩下的桃子吃掉一半，又多吃了一个。
# 以后每天早上都吃了前一天剩下的一半零一个。到第10天早上想再吃时，见只剩下一个桃子了。求第一天共摘了多少
# peach = 1
# for i in range(9,0,-1):
#     peach = (peach + 1) * 2
# print(peach)

# 两个乒乓球队进行比赛，各出三人。甲队为a, b, c三人，乙队为x, y, z三人。
# 已抽签决定比赛名单。有人向队员打听比赛的名单。
# a说他不和x比，c说他不和x, z比，请编程序找出三队赛手的名单
# for i in range(ord('x'), ord('z') + 1):
#     for j in range(ord('x'), ord('z') + 1):
#         if i != j:
#             for k in range(ord('x'), ord('z') + 1):
#                 if (i != k) and (j != k):
#                     if (i != ord('x')) and (k != ord('x')) and (k != ord('z')):
#                         print(f'Opponent a - {chr(i)}, b - {chr(j)}, c - {chr(k)}')

# 打印如下图案
#    *
#   ***
#  *****
# *******
#  *****
#   ***
#    *
# shape = '*'
# s = []
# for i in range(1, 5):
#     if i <= round(7 / 2):
#         print(f'{shape * ((i * 2) - 1)}'.center(7))
#         s.append(f'{shape * ((i * 2) - 1)}')
# s = sorted(s, reverse=True)
# for x in s[1:]:
#     print(x.center(7))

# 有一分数序列：2/1，3/2，5/3，8/5，13/8，21/13...求出这个数列的前20项之和
# son,mom = 2,1
# summary = 0
# for i in range(1,21):
#     summary += son / mom
#     son,mom = mom+son,son
# print(summary)

# 请输入星期几的第一个字母来判断一下是星期几，如果第一个字母一样，则继续判断第二个字母
# day = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
# d = input("Please input letter of day:").lower()
# def check_letter(letter):
#     for i in day:
#         i = i.lower()
#         for j in range(len(i)):
#             if i[:j + 1] == letter[:j + 1] and (letter in i) and letter != i:
#                 if letter in i and len(letter) == 2:
#                     return i
#                 letter += input("Please input next letter of day:").lower()
#             elif i == letter:
#                 return i
#             else:
#                 break
#     print('Error input!')
# print(check_letter(d).title())

# 按相反的顺序输出列表的值
# li = [i for i in range(5)]
# print(sorted(li,reverse=True))
# print(li[::-1])
# li.sort(reverse=True)
# print(li)

# 按逗号分隔列表
# li = [i for i in range(5)]
# print(','.join(str(j) for j in li))

# 求100之内的素数
# for i in range(1, 101):
#     if i > 1:
#         for j in range(2, i):
#             if i % j == 0:
#                 break
#         else:
#             print(i)

# 求一个3*3矩阵主对角线元素之和
# from random import randint
#
# li = [[randint(1, 10) for _ in range(3)] for j in range(3)]
# summary = 0
# for i in range(len(li)):
#     summary += li[i][i]
# print(summary)

# 有一个已经排好序的数组。现输入一个数，要求按原来的规律将它插入数组中
# li = [i for i in range(10)]
# insert_num = int(input())
# print(li)
# for i in li:
#     if i >= insert_num and (insert_num >= 0):
#         li.insert(li.index(i+1),insert_num)
#         break
#     elif insert_num > li[-1]:
#         li.append(0)
#         li[-1] = insert_num
#         break
#     elif insert_num < li[0]:
#         li.insert(li.index(i), insert_num)
#         break
# print(li)

# 两个 3 行 3 列的矩阵，实现其对应位置的数据相加，并返回一个新矩阵：

# X = [[12, 7, 3],
#      [4, 5, 6],
#      [7, 8, 9]]
#
# Y = [[5, 8, 1],
#      [6, 7, 3],
#      [4, 5, 9]]
# new_li = []
# for i in range(3):
#     # new_li = list(map(lambda x, y: list(map(lambda xx, yy: xx + yy, x, y)), X, Y))
#     new_li = (list(map(lambda x,y:x+y,X[i],Y[i])))
#     print(new_li)
# # for i in new_li:
# #     print(i)

# 求输入数字的平方，如果平方运算后小于 50 则退出
# while True:
#     num = int(input())
#     if math.pow(num,2) < 50:
#         print(f'Pow {num} of 2 is:{pow(num, 2)}')
#         break
#     print(f'Pow {num} of 2 is:{pow(num,2)}')

# random 函数的使用
# print(random.random())  # 返回随机浮点数
# print(random.uniform(1, 3))  # 返回指定范围随机浮点数
# print(random.randint(1, 3))  # 返回指定范围随机整数
# print(random.randrange(10, 20, 2))  # 返回指定范围集合中的随机数
# print(random.choice(range(10, 20, 2)))  # 从指定序列中挑选任意一个值返回
#
# li = [i for i in range(10)]
# random.shuffle(li)  # 将指定序列中元素打乱返回
# print(li)
# print(random.sample(li, 3))  # 从指定序列中获取指定长度的随机数序列
#
# random.seed(10)  # 随机数种子使得接下来生成有规律的随机数
# print(random.random(), random.random(), random.random())

# 取一个整数a从右端开始的4〜7位
# num = int(input())
# r_shift = num >> 4  # 初始数右移，将高位值移到低位，从而得到从右往左位数的值
# reverse = ~(~0 << 4)  # 设置“与”条件，将低位值全置为1高位置为0
# final_res = r_shift & reverse  # 通过按位“与”即可得到所需值
# print(final_res)

# 打印出杨辉三角形
# num = int(input())
# row = []
# for i in range(num):
#     row.append([])
#     for j in range(i + 1):
#         if j == 0 or i == j:
#             row[i].append(1)
#         else:
#             row[i].append(row[i-1][j] + row[i-1][j-1])
# for k in row:
#     for l in k:
#         print(l,end='\t')
#     print()

# 有 n 个整数，使其前面各数顺序向后移 m 个位置，最后 m 个数变成最前面的 m 个数
# num = [1,2,3,4,5,6,7,8,9]
# m = int(input())
# print(num[-m:]+num[:len(num) - m])

# 有n个人围成一圈，顺序排号。从第一个人开始报数（从1到3报数），凡报到3的人退出圈子，问最后留下的是原来第几号的那位
# people = [i for i in range(1, int(input()) + 1)]
# i = 1
# while len(people) > 1:
#     if i % 3 == 0:
#         people.pop(0)
#     else:
#         people.insert(len(people), people.pop(0))
#     i += 1
# print(people)

# 编写一个函数，输入n为偶数时，调用函数求1/2+1/4+...+1/n,当输入n为奇数时，调用函数1/1+1/3+...+1/n
# def call_func(n):
#     summary = 0
#     def even_func():
#         nonlocal summary
#         for i in range(1,n+1):
#             if i % 2 == 0:
#                 summary += 1/i
#         return summary
#     def odd_func():
#         nonlocal summary
#         for i in range(1,n+1):
#             if i % 2 != 0:
#                 summary += 1/i
#         return summary
#     if n % 2 == 0:
#         return even_func()
#     else:
#         return odd_func()
# print(call_func(int(input())))

# 海滩上有一堆桃子，五只猴子来分。第一只猴子把这堆桃子平均分为五份，多了一个，这只猴子把多的一个扔入海中，拿走了一份。
# 第二只猴子把剩下的桃子又平均分成五份，又多了一个，它同样把多的一个扔入海中，拿走了一份，
# 第三、第四、第五只猴子都是这样做的，问海滩上原来最少有多少个桃子？
# peach = 6
# while True:
#     total = peach
#     enough = True
#     for _ in range(5):
#         if (total - 1) % 5 == 0:
#             total = (total - 1) // 5 * 4
#         else:
#             enough = False
#             break
#     if enough:
#         print(peach)
#         break
#     peach += 5

# 809*??=800*??+9*?? 其中??代表的两位数, 809*??为四位数，8*??的结果为两位数，9*??的结果为3位数。求??代表的两位数，及809*??后的结果
# res = 809
# for i in range(10,100):
#     multiple = res * i
#     if (multiple > 1000) and (multiple < 10000) and (8 * i < 100) and (9 * i >= 100):
#         print(f'?? = {i},809 * {i} = {809 * i}')

# 求0—7所能组成的奇数个数
# numbers, summary = 0, 0
# for i in range(1, 9):
#     if i == 1:  # 一位数4
#         numbers += 4
#         summary += numbers
#     elif i == 2:  # 二位数7 * 4, 末尾只能是1，3，5，7，首位只能是除0外的数
#         numbers = numbers * 7
#         summary += numbers
#     else:
#         numbers = numbers * 8  # 多位数7 * 8...8 * 4
#         summary += numbers
# print(summary)

# 输入一个奇数，然后判断最少几个 9 除于该数的结果为整数
# odd = int(input())
# divider = '9'
# if odd % 2 != 0:
#     while True:
#         if int(divider) % odd == 0:
#             print(f'{divider} / {odd} = {int(divider) / odd}')
#             break
#         divider += '9'

# 读取7个数（1—50）的整数值，每读取一个值，程序打印出该值个数的＊
# for _ in range(7):
#     print(random.choice(range(1,51)) * '*')

# 某个公司采用公用电话传递数据，数据是四位的整数，在传递过程中是加密的，加密规则如下：
# 每位数字都加上5,然后用和除以10的余数代替该数字，再将第一位和第四位交换，第二位和第三位交换
# data = input()
# new_data = map(lambda x: (int(x) + 5) % 10, data) if len(data) == 4 else print('Input Error!')
# new_data = [i for i in list(new_data)]
# new_data.reverse()
# print(new_data)




























