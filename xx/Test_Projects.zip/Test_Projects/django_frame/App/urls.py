"""django_frame URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, re_path

from App import views

app_name = 'App'
urlpatterns = [
    path('index/',views.index,name='index'),
    # str参数类型，默认是str类型不必定义类型,不匹配/
    path('change/<name>/', views.change, name='change'),
    # int类型，定义匹配传入的参数是否是int类型
    path('age/<name>/<int:age>/', views.age, name='age'),
    # slug类型，定义传入的参数包含数字，字母，_,-
    path('user/<slug:name>/', views.user, name='user'),
    # path类型，定义传入的非空参数包含/
    path('path/<path:path>/', views.path, name='path'),
    # re_path以正则表达式的方式检验传入的参数是否匹配,如果是命名规则组，则视图函数需传入对应命名关键字
    re_path(r'tel/(\d{8})/$', views.phone, name='phone'),
    re_path(r'phone/(?P<phone>\d{8})/$', views.get_phone, name='tel'),
    path('http_response/', views.handle_response, name='Handle_response'),
    path('redirect/', views.redir, name='redirect'),
    path('variable/', views.var, name='variable'),
    path('register/', views.register, name='register'),
    path('child/', views.inherit, name='child'),
    path('main/', views.main, name='main')
]
