import django.views.defaults
from django.http import HttpResponse, JsonResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse

# Create your views here.
from django.views.decorators.csrf import csrf_exempt


def index(request):
    # return HttpResponse('Hello World')
    return render(request, 'index.html', context={'name': 'Jack'})


def age(request, name, age):
    return HttpResponse(name + ':' + str(age))


def user(request, name):
    return HttpResponse(name)


def path(request, path):
    return HttpResponse(path)


def phone(request, phone):
    return HttpResponse(phone)


def get_phone(request, phone):
    # GET传参的获取
    print(request.GET.get('name'))
    print(request.GET.getlist('age'))
    # POST参数获取
    # request.POST.get('')
    # request.POST.getlist('')
    # 请求方式的获取
    print('Request_method:', request.method)
    # 请求路径的获取
    print('Request_path:', request.path)
    # 其它请求数据
    print(request.META)
    # 客户端地址
    print('Remote_addr:', request.META.get('REMOTE_ADDR'))
    # 来源页面（从其它页面跳转）
    print('Original_page:', request.META.get('HTTP_REFERER'))
    # 获取完整路径
    print(request.get_full_path())
    # 获取主机地址及端口号
    print(request.get_host())
    # 获取url
    print(request.build_absolute_uri())
    # 获取请求参数的字典
    print(request.GET.dict())
    return HttpResponse(phone)


def change(request, name):
    print(1 / 0)
    return HttpResponse(name)


def handle_response(request):
    # res = HttpResponse('响应对象')
    # res.content_type = 'text/html'
    # res.charset = 'utf8'
    # res.status_code = 200
    # return res

    # render返回响应对象
    # res = render(request, 'index.html', context={'name':'Lily'})
    # return res

    # JsonResponse返回json字符串,非字典则需要将safe设置为False
    print(request.META.get('HTTP_REFERER'))
    return JsonResponse({'name': 'Jack', 'age': 18})


def redir(request):
    # return HttpResponseRedirect('/index/')
    # 应用内跳转不需要加http前缀
    # return redirect('/index/')
    # 应用外跳转得到对应url即可
    # return redirect('https://www.baidu.com')

    # 反向定位
    # 不带参数的定位
    # print(reverse("App:index"))
    # return redirect(reverse("App:index"))
    # 带参数的定位
    # print(reverse("App:age",kwargs={'name':'Jack','age':18}))
    # return redirect(reverse("App:age",kwargs={'name':'Jack','age':18}))
    print(reverse("App:age", args=('jack', 123,)))
    return redirect(reverse("App:age", args=('jack', 123,)))
    # print(reverse('App:phone', args=('12345678',)))
    # return redirect(reverse('App:phone', args=('12345678',)))


def var(request):
    num = 10
    name = 'Lucy'
    age = [10, 20, 30, [40, 50]]
    user = {'name': 'Jack', 'age': 18}
    Hello = None
    text = '<h1>将字符<,>进行转义输出到页面上</h1>'
    return render(request, 'index.html', locals())


# 局部禁止
@csrf_exempt  # 加上此装饰器，则html页面中就不需要提交{% csrf_token %}，否则会失败
def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
    return render(request, 'register.html')


def inherit(request):
    return render(request,'child.html', {'Title':'继承自base.html'})


def main(requset):
    return render(requset,'main.html')