# 自定义过滤器,在应用中创建templatetags包
from django import template

register = template.Library()


@register.filter(name='multiple2')
def multiple(value, strvlaue='Hello'):
    if isinstance(value, int):
        return int(value) * 2
    else:
        return strvlaue + value
