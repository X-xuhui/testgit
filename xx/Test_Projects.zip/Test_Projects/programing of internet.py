import os
import random
import socket

# udp发送接受信息
# s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
# s.bind(('10.104.56.22',2121))
# s.sendto('你好'.encode('utf8'),('10.104.56.22',2121))
# content = s.recvfrom(1024)
# print(content[0].decode('utf8'))
# s.close()

# tcp发送接受信息
# s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
# s.connect(('10.104.56.22',2121))
# s.send('How are you!'.encode('utf8'))
# s.close()

# s.bind(('10.104.56.22',2121))
# s.listen(128)
# content = s.accept()
# data = content[0].recv(1024)
# print(data.decode('utf8'))
# s.close()

# tcp文件服务器
# server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# server.bind(('10.104.58.44', 2121))
# server.listen(128)
# # 客户端请求，客户端地址[ip,port]
# client_req, client_addr = server.accept()
# file_name = client_req.recv(1024).decode('utf8')
# print(f'客户端地址{client_addr[0]}，端口号{client_addr[1]},请求内容:{file_name}')
# if os.path.isfile(file_name):
#     with open(file_name, 'r', encoding='utf8') as fp:
#         content = fp.read()
#         client_req.send(content.encode('utf8'))
# else:
#     print('文件不存在！')
# server.close()

# 客户端请求
# client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# client.connect(('10.104.58.44', 2121))
# file_name = input('请输入要下载的内容：')
# client.send(file_name.encode('utf8'))
# data = client.recv(1024).decode('utf8')
# with open(file_name, 'w', encoding='utf8') as fp:
#     fp.write(data)
# client.close()

# 多线程聊天
# import threading
# s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
# s.bind(('10.104.58.44', 2121))
# def send_msg():
#     while True:
#         msg = input('请输入内容：')
#         s.sendto(msg.encode('utf8'), ('10.104.58.44', 2121))
#         if msg == 'exit':
#             break
# def recv_msg():
#     while True:
#         content = s.recvfrom(1024)
#         print(f'接收到{content[0].decode("utf8")}', file=open('record.txt', 'a', encoding='utf8'))
# a = threading.Thread(target=send_msg())
# b = threading.Thread(target=recv_msg())
# a.start()
# b.start()

# 多进程
import multiprocessing
import time
# def jump(n):
#     for i in range(n):
#         time.sleep(0.5)
#         print(f'Jump{i}次')
# def run(n):
#     for i in range(n):
#         time.sleep(0.5)
#         print(f'run{i}米')
# if __name__ == '__main__':
#     p1 = multiprocessing.Process(target=jump, args=(10,))
#     p2 = multiprocessing.Process(target=run, args=(10,))
#     p1.start()
#     p2.start()

# 多进程通信
from multiprocessing import Queue
# def producer(q):
#     for i in range(10):
#         time.sleep(0.5)
#         print(f'生产了{i}个蛋糕')
#         q.put(f'pid {os.getpid()} {i}')
#
# def consumer(q):
#     while True:
#         time.sleep(1)
#         print(f'买了蛋糕{q.get()}')
#
# if __name__ == '__main__':
#     q = Queue()
#     p1 = multiprocessing.Process(target=producer,args=(q,))
#     c1 = multiprocessing.Process(target=consumer,args=(q,))
#     p1.start()
#     c1.start()

# 进程池
from multiprocessing import Pool
# def work(p):
#     start = time.time()
#     print(f'进程{p}开始执行,进程号{os.getpid()}')
#     time.sleep(random.random() * 2)
#     stop = time.time()
#     print(f'进程{p}执行耗时{(stop - start):.2f}')
#
# if __name__ == '__main__':
#     pool = Pool(3)
#     print('start')
#     for i in range(1,11):
#         pool.apply_async(work,(i,))
#     pool.close()
#     pool.join()
#     print('end')

# 进程池中进程间通信
from multiprocessing import Manager
# def read(q):
#     for i in range(q.qsize()):
#         print(f'从Queue中获取{q.get()}')
# def write(q):
#     for i in 'Hello World':
#         q.put(i)
# if __name__ == '__main__':
#     q = Manager().Queue()
#     pool = Pool()
#     pool.apply_async(write, (q,))
#     time.sleep(3)
#     pool.apply_async(read, (q,))
#     pool.close()
#     pool.join()  # 让主进程等待子进程执行完毕

# wsgi服务器的搭建
# from wsgiref.simple_server import make_server
# def show_index():
#     return '欢迎来到首页'
# def show_register():
#     return '请注册'
# def show_login():
#     return '欢迎来到登录页面'
# def demo_app(environ, start_response):
#     path = environ['PATH_INFO']
#     status_code = '200 OK'
#     print(environ['QUERY_STRING'])
#
#     url = {'/': show_index, '/register': show_register, '/login': show_login}
#     method = url.get(path)
#     if method:
#         response = method()
#     else:
#         status_code = '404 Page Not Found'
#         response = '页面资源不存在'
#
#     start_response(status_code, [('Content-Type', 'text/html;charset=utf8')])
#     return [response.encode('utf8')]
# if __name__ == '__main__':
#     httpd = make_server('', 8000, demo_app)  # ''等同于'0.0.0.0'
#     sa = httpd.socket.getsockname()
#     print('Serving HTTP on', sa[0], 'port', sa[1], '...')
#     httpd.serve_forever()

print('hello')
