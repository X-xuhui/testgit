import os
import re
import shutil
import string

dimms = """
$ddr_type = "DDR5"
$default_spd_info = "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"
$dimms = []
$dimms += [[0, 1, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
$dimms += [[1, 1, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
"""


def get_uart_tables(table_name, log_path=None, line_limit=1000):
    log_path = log_path or GetPath.uart_log
    if not os.path.exists(log_path):
        err = 'simics uart log:{} not found!'.format(log_path)
        debug_log.error(err)
        return []
    with open(log_path, 'r') as fp:
        lines = fp.readlines()
    start_flag = False
    tables = []
    table_line = []
    for line in lines:
        line = line.strip()
        # drop oversize data
        if len(table_line) > line_limit:
            table_line = []
            start_flag = False

        if not start_flag:
            if line == 'START_' + table_name:
                start_flag = True
                table_line = []
            continue

        if line == 'STOP_' + table_name:
            tables.append(table_line)
            start_flag = False
            continue
        table_line.append(line)

    return tables


def get_uart_dimminfo(log_path, socket=0):
    """
    return {
        "channel0": {
            "slot0": [],
            "slot1": []
        },
        "channel1": {
            "slot0": [],
            "slot1": []
        }
    }
    """
    table_name = 'SOCKET_{}_DIMMINFO_TABLE'.format(socket)
    dimm_tables = get_uart_tables(table_name, log_path)
    if not dimm_tables:
        debug_log.error('{} Not Found!'.format(table_name))
        return {}
    dimm_table = dimm_tables[0]
    slots = {}
    slot_no = 's'
    for line in dimm_table:
        _chs = line.split('|')
        if not len(_chs) > 1:
            continue
        if _chs[0].strip():
            slot_no = _chs[0].strip().lower()
            slots[slot_no] = []
        slots[slot_no].append([ch.replace(' ', '').lower() for ch in _chs[1:-1]])

    channel_ths = slots.pop('s')[0]
    dimm_dict = {}
    for id_th, ch in enumerate(channel_ths):
        dimm_dict[ch] = {}
        for s_name, s_list in slots.items():
            dimm_dict[ch]['slot' + s_name] = [tr[id_th] for tr in s_list]

    return dimm_dict


class MemoryInfo:
    """
    params:log_path,spd_file,mapping_relation
        extract_spd_info() extract Memory information.
        Example:
           type:dict dimm0:{
               'slot': '0',
               'socket': '0',
               'die': '1',
               'type': {'Vendor': 'Hynix', 'Data width': '16gbx8', 'Rank': 'SR', 'Frequency': 'DDR5-4800', 'Type(MCR)': 'DDR5',
                        'Message': '16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix', 'Size': '16GB'},
               'generate': 'DDR5',
               'channel': '0'}

        get_single_info() from spd file get target information,include.
        Example:
            page_expected_res ==> type:list ['Socket0.ChA.Dimm0: 4800MT/s Hynix SRx8 16GB RDIMM'...]
            dimm_table_expected_res ==> type:list[dict] [{'width': '16gbx8', 'vendor': 'Hynix', 'generate': 'DDR5', 'rank': 'DR', 'size': '32GB'}...]
            alphabet ==> type:list ['A'...]
    """

    mapping = {
        'Socket0': {
            'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
            'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
            'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}},
        'Socket1': {
            'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
            'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
            'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}}
    }

    def __init__(self, *args, **kwargs):
        self.log = args[0]
        self.spd_info = kwargs.get('spd')
        self.map_relation = kwargs.get('map')

    @staticmethod
    def extract_spd_info(spd_file):
        pattern = re.compile(r'\$dimms \+= .+')
        dimms = re.findall(pattern, spd_file)
        dimm_list = []
        dimm_dict = {}
        kw = ['socket', 'die', 'channel', 'slot', 'generate', 'type']

        def filter_type():
            kw_list = ['Size', 'Data width', 'Rank', 'Frequency', 'Type(MCR)', 'Vendor', 'Message']
            line = dimm_list[num][-1].split('_')
            size = line[0]
            width = '16gb%s' % line[1][2:]
            rank = line[1][:2]
            frequency = line[3] + '-' + line[2]
            form = line[3]
            vendor = line[-1]
            val = [size, width, rank, frequency, form, vendor, dimm_list[num][-1]]
            return dict(zip(kw_list, val))

        for num, dimm in enumerate(dimms):
            info = dimm.split('=')[1].strip().replace('[[', '')
            info = info.replace(']]', '')
            info = info.replace('"', '')
            info = info.replace('.txt', '')
            info = info.replace(' ', '').split(',')
            dimm_list.append(info)
            dimm_list[num].insert(-1, filter_type())
            dimm_dict['dimm%s' % num] = dict(zip(kw, info))
        return dimm_dict

    def check_dimminfo_table(self, socket, channel, slot):
        dimm_table = get_uart_dimminfo(self.log, socket)
        kw = ['vendor', 'generate', 'size', 'width', 'rank']
        val = []
        slot_info = dimm_table.get('channel%s' % channel).get('slot%s' % slot)
        try:
            vendor = slot_info[0][5:].title()
            generate = slot_info[15][:4].upper()
            size = slot_info[14][:4].upper()
            width = re.search(r'\((?P<val>\d+gb.\d)', slot_info[14]).group('val')
            rank = re.search(r'[sd]r', slot_info[14]).group().upper()
            val.extend([vendor, generate, size, width, rank])
            dimm_table_dict = dict(zip(kw, val))
            return dimm_table_dict
        except Exception as e:
            raise e

    def get_single_info(self):
        page_expected_res = []
        dimm_table_expected_res = []
        alphabet = []
        for idx, dimm in enumerate(self.spd_info):
            spd_file = self.spd_info.get(dimm)
            soc = spd_file.get('socket')
            die = spd_file.get('die')
            cha = spd_file.get('channel')
            slot = spd_file.get('slot')
            generate = spd_file.get('generate')
            vendor = spd_file.get('type').get('Vendor')
            width = spd_file.get('type').get('Data width')
            size = spd_file.get('type').get('Size')
            rank = spd_file.get('type').get('Rank')
            frequency = spd_file.get('type').get('Frequency')
            ty_mcr = spd_file.get('type').get('Type(MCR)')
            message = spd_file.get('type').get('Message').split('_')
            letter = self.map_relation.get('Socket%s' % soc).get('Die%s' % die).get(cha)
            txt_channel = string.ascii_uppercase.index(letter)
            alphabet.append(letter)
            page_expected_res.append(
                ('Socket{}.Ch{}.Dimm{}: {}MT/s {} {} {} {}'.format(soc, letter, slot, message[2],
                                                                   vendor, message[1], size,
                                                                   message[4])))
            dimm_table_dict = self.check_dimminfo_table(soc, txt_channel, slot)
            dimm_table_expected_res.append(dimm_table_dict)
        return page_expected_res, dimm_table_expected_res, alphabet


def positionlines(lines, start, end):
    start_flag = False
    start_pos = end_pos = -1
    for idx, line in enumerate(lines):
        if line.lower().startswith(start.lower()):
            start_pos = idx
            start_flag = True
            continue
        if start_flag and line.lower().startswith(end.lower()):
            end_pos = idx
            break
    if start_pos == -1 or end_pos == -1:
        raise Exception('Not found position')
    return start_pos, end_pos


def change_script(sim_script, dimm_info, delete=None):
    shutil.copy(sim_script, sim_script + '.bak')
    with open(sim_script, 'r+') as old, open('%s.zz' % sim_script, 'w+') as new:
        sim_lines = old.readlines()
        start_idx, end_idx = positionlines(sim_lines, '$script_type',
                                           'run-command-file')
        if dimm_info:
            if '$dimms' in ''.join(sim_lines):
                old_dimms = re.findall('\$dimms.*', ''.join(sim_lines))
                for i in old_dimms:
                    sim_lines.remove(i + '\n')
            if delete:
                del sim_lines[start_idx:end_idx + 1]
            sim_lines.insert(start_idx + 1, dimm_info)
        new.writelines(''.join(sim_lines))
        old.close()
        os.remove(sim_script)
        new.close()
        os.rename('%s.zz' % sim_script, sim_script)
    shutil.move(sim_script + '.bak', sim_script)


def main():
    log_path = r'C:\Users\xuhuixux\Downloads\simics_uart.log'
    spd = MemoryInfo(log_path, map=MemoryInfo.mapping, spd=MemoryInfo.extract_spd_info(dimms))
    spd.get_single_info()


if __name__ == '__main__':
    main()
