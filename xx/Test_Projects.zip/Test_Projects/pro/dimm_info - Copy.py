import os
import re
import shutil
import string


def get_uart_tables(table_name, log_path=None, line_limit=1000):
    log_path = log_path or GetPath.uart_log
    if not os.path.exists(log_path):
        err = 'simics uart log:{} not found!'.format(log_path)
        debug_log.error(err)
        return []
    with open(log_path, 'r') as fp:
        lines = fp.readlines()
    start_flag = False
    tables = []
    table_line = []
    for line in lines:
        line = line.strip()
        # drop oversize data
        if len(table_line) > line_limit:
            table_line = []
            start_flag = False

        if not start_flag:
            if line == 'START_' + table_name:
                start_flag = True
                table_line = []
            continue

        if line == 'STOP_' + table_name:
            tables.append(table_line)
            start_flag = False
            continue
        table_line.append(line)

    return tables


def get_uart_dimminfo(log_path, socket=0):
    """
    return {
        "channel0": {
            "slot0": [],
            "slot1": []
        },
        "channel1": {
            "slot0": [],
            "slot1": []
        }
    }
    """
    table_name = 'SOCKET_{}_DIMMINFO_TABLE'.format(socket)
    dimm_tables = get_uart_tables(table_name, log_path)
    if not dimm_tables:
        debug_log.error('{} Not Found!'.format(table_name))
        return {}
    dimm_table = dimm_tables[0]
    slots = {}
    slot_no = 's'
    for line in dimm_table:
        _chs = line.split('|')
        if not len(_chs) > 1:
            continue
        if _chs[0].strip():
            slot_no = _chs[0].strip().lower()
            slots[slot_no] = []
        slots[slot_no].append([ch.replace(' ', '').lower() for ch in _chs[1:-1]])

    channel_ths = slots.pop('s')[0]
    dimm_dict = {}
    for id_th, ch in enumerate(channel_ths):
        dimm_dict[ch] = {}
        for s_name, s_list in slots.items():
            dimm_dict[ch]['slot' + s_name] = [tr[id_th] for tr in s_list]

    return dimm_dict


dimms = """
$ddr_type = "DDR5"
$default_spd_info = "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"
$dimms = []
$dimms += [[0, 1, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
$dimms += [[1, 1, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
"""
# dimms = """
# $ddr_type = "DDR5"
# $default_spd_info = "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"
# $dimms = []
# $dimms += [[1, 0, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
# $dimms += [[1, 0, 1, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
# $dimms += [[1, 1, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
# $dimms += [[1, 1, 1, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
# $dimms += [[1, 2, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
# $dimms += [[1, 2, 1, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
# """
ret = '''Handle 0x0001, DMI
            Size : 16GB
            Speed : 4800 MT/s
            Logical Size : None
Handle 0x0002, DMI
            Size : No Module Installed
Handle 0x0011, DMI
            Size : No Module Installed
Handle 0x0012, DMI
            Size : No Module Installed
Handle 0x0013, DMI
            Size : No Module Installed
Handle 0x0019, DMI
            Size : No Module Installed
Handle 0x001A, DMI
            Size : 16GB
            Speed : 4800 MT/s
            Logical Size : None
Handle 0x001B, DMI
            Size : No Module Installed
Handle 0x0024, DMI
            Size : 64GB
            Speed : 4800 MT/s
            Logical Size : None
Handle 0x0025, DMI
            Size : No Module Installed'''

os_res = ['dmidecode --type memory | grep -i -e DMI -e size -e speed', '# dmidecode 3.2',
          '# fully supported by this version of dmidecode.', 'Handle 0x0000, DMI type 16, 23 bytes',
          'Handle 0x0001, DMI type 17, 92 bytes', '\tSize: 16 GB', '\tSpeed: 4800 MT/s',
          '\tConfigured Memory Speed: 4800 MT/s', '\tNon-Volatile Size: None', '\tVolatile Size: 16 GB',
          '\tCache Size: None', '\tLogical Size: None', 'Handle 0x0002, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0003, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0004, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0005, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0006, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0007, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0008, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0009, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x000A, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x000B, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x000C, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x000D, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x000E, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x000F, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0010, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0011, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0012, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0013, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0014, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0015, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0016, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0017, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0018, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0019, DMI type 17, 92 bytes', '\tSize: 16 GB', '\tSpeed: 4800 MT/s',
          '\tConfigured Memory Speed: 4800 MT/s', '\tNon-Volatile Size: None', '\tVolatile Size: 16 GB',
          '\tCache Size: None', '\tLogical Size: None', 'Handle 0x001A, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x001B, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x001C, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x001D, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x001E, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x001F, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0020, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0021, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0022, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0023, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0024, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0025, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0026, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x0027, DMI type 17, 92 bytes', '\tSize: No Module Installed',
          'Handle 0x0028, DMI type 17, 92 bytes', '\tSize: No Module Installed', 'Handle 0x0029, DMI type 17, 92 bytes',
          '\tSize: No Module Installed', 'Handle 0x002A, DMI type 17, 92 bytes', '\tSize: No Module Installed']


class a:
    # def check_dimm_system_table(self,path):
    #     table = get_uart_tables('DIMMINFO_SYSTEM_TABLE', path)
    #     for i in table[0]:
    #         m = re.search(r'Active Memory\s*\|(?P<val>.*)', i)
    #         if not m:
    #             continue
    #         res = m.group('val').split('|')
    #         print 'Active Memory:{}'.format(res[0]) if res[0].strip() == res[1].strip() else 1

    def check_dimm_system_table(self, path):
        table = get_uart_tables('DIMMINFO_SYSTEM_TABLE', path)
        for i in table[0]:
            m = re.search(r'DDR Freq.+(?P<val>[^|]DDR.*)[^|]', i)
            if not m:
                continue
            res = m.group('val')
            return 'Frequency:{}'.format(res.strip())

    def check_tables_target_info(self, path):
        dimm = self.extract_dimm_info()
        dimm_sys = self.check_dimm_system_table(path)
        soc = dimm[2]
        ch = dimm[3]
        sl = dimm[1]
        contend = dimm[4]
        for idx, socket in enumerate(soc):
            dimm_table = get_uart_dimminfo(path, socket[-1])
            slot_info = dimm_table.get(ch[idx]).get('slot{}'.format(sl[idx]))
            for i in slot_info:
                if i == '':
                    slot_info.remove(i)
            dimm_dict = {}
            for j in slot_info:
                m = re.search('^\d+gb', j)
                if not m:
                    continue
                start_idx = slot_info.index(j)
                dimm_info = ''.join(slot_info[start_idx:-1])
                dimm_dict['dimm_info'] = dimm_info
                break
            new_slot_info = []
            for k in slot_info:
                if ':' not in k:
                    break
                new_slot_info.append(k.split(':'))
            new_slot_info_dict = dict(new_slot_info)
            new_slot_info_dict.update(dimm_dict)
            vendor = new_slot_info_dict.get('dimm')
            dimm = new_slot_info_dict.get('dimm_info')
            type = re.search(r'ddr\d+', dimm).group()
            size = re.search(r'^\d+gb', dimm).group()
            data_width = re.search(r'\((?P<val>\d+gb.\d)', dimm).group('val')
            rank = re.search(r'[sd]r', dimm).group()
            dimm_info_list = ['Socket:{}'.format(socket), 'Channel:{}'.format(ch[idx]), 'Vendor:{}'.format(vendor),
                              'Type(MCR):{}'.format(type),
                              'Size:{}'.format(size), 'Data width:{}'.format(data_width), 'Rank:{}'.format(rank)]
            contend_trans = [l[:-1] for l in contend]
            if set(dimm_info_list[2:]).issubset(contend_trans[idx]) and dimm_sys.lower() in contend[idx][-1].lower():
                print
                '{}'.format(contend[idx])

    def extract_dimm_info(self):
        self.mapping = {
            'Socket0': {
                'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
                'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
                'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}},
            'Socket1': {
                'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
                'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
                'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}}
        }
        position = []
        socket = []
        letter = []
        channel = []
        channel_list = []
        slot = []
        text = []
        dimm_txt = []
        idx = 0
        for dimm in dimms.split('\n'):
            m = re.search(r'\[(?P<val>\d.+), "DDR5".*"(?P<txt>\d+[gG][bB].*[^]])', dimm)
            if not m:
                continue
            res = m.group('val').replace(', ', '')
            txt = m.group('txt').split('_')
            position.extend(
                [('Socket{}'.format(res[0]),
                  'Die{}'.format(res[1]),
                  '{}'.format(res[2]),
                  'Slot{}'.format(res[3]),
                  'Vendor:{}'.format(txt[-1].replace('.txt"', '').lower()),
                  'Type(MCR):{}'.format(txt[3].lower()),
                  'Size:{}'.format(txt[0].lower()),
                  'Data width:{}'.format((txt[0] + txt[1][2:]).lower().lower()),
                  'Rank:{}'.format(txt[1][:2].lower()),
                  'Frequency:{}'.format((txt[3] + '-' + txt[2]).lower()))
                 ])
            slot.append(res[3])
            channel.append([res[2]])
            text.append(position[idx][4:])
            dimm_txt.append('{}MT/s {} {} {} {}'.format(txt[2], txt[-1].replace('.txt"', ''), txt[1], txt[0], txt[4]))
            idx += 1
        for so in position:
            socket.append(so[0])
        for loc in range(len(position)):
            ele = self.mapping.get(position[loc][0]).get(position[loc][1]).get(position[loc][2])
            letter.append(ele)
            pos = string.ascii_uppercase.index(ele)
            channel_list.append('channel{}'.format(pos))
        return letter, slot, socket, channel_list, text, dimm_txt

    def create_socket_info_dict(self, os_res):
        alphabet = []
        slot = []
        start_idx = ''
        for s in os_res:
            m = re.search(r'Handle (?P<val>0x[a-fA-F0-9]+)', s)
            if not m:
                continue
            start_idx = int(m.group('val'), 16)
            break
        for i in range(start_idx + 1, start_idx + 49):
            slot.append("0x%04x" % i)
        for j in range(2):
            for l in range(ord('a'), ord('l') + 1):
                alphabet.append(chr(l) + str(j))
        alphabet.sort()
        slot0 = sorted(dict(zip(alphabet, slot[:24])).items())
        slot1 = sorted(dict(zip(alphabet, slot[24:48])).items())
        slot_set = [slot0, slot1]
        socket = {}
        socket_name = ['Socket0', 'Socket1']
        for idx in range(2):
            alphabet_dict = {}
            for al in string.ascii_uppercase[:12]:
                alphabet_dict[al] = slot_set[idx][:2]
                socket[socket_name[idx]] = alphabet_dict
                del (slot_set[idx][:2])
        return socket

    def check_target_size_speed(self, os_res):
        extract_dimm = self.extract_dimm_info()
        socket_dict = self.create_socket_info_dict(os_res)
        socket = extract_dimm[2]
        slot_num = extract_dimm[1]
        size_speed = os_res
        uninstall = []
        count = 0
        for un in size_speed:
            m = re.search(r'No Module Installed', un)
            if not m:
                continue
            unavailable = m.group()
            uninstall.append(unavailable)
        for idx, key in enumerate(socket):
            target_slot = dict({key: socket_dict.get(key).get(extract_dimm[0][idx])})
            m = re.search(r'0x[a-fA-F0-9]+', target_slot.get(key)[int(slot_num[idx])][1])
            if not m:
                continue
            res = m.group()
            for start in size_speed:
                s = re.search('0x' + '{}'.format(hex(int(res, 16))).replace('0x', '').upper().zfill(4), start)
                if not s:
                    continue
                start_idx = size_speed.index(start)
                for end in size_speed:
                    e = re.search('0x' + '{}'.format(hex(int(res, 16) + 1)).replace('0x', '').upper().zfill(4), end)
                    if not e:
                        continue
                    end_idx = size_speed.index(end)
                    target_info = size_speed[start_idx:end_idx]
                    log2all(target_info)
                    count += 1
                    break
                break
        if len(uninstall) + count == 48:
            pass
        # else:
        #     self.count += 1


class MemoryInfo:
    """
    params:log_path,spd_file,mapping_relation
        extract_spd_info() extract Memory information.
        Example:
           type:dict dimm0:{
               'slot': '0',
               'socket': '0',
               'die': '1',
               'type': {'Vendor': 'Hynix', 'Data width': '16gbx8', 'Rank': 'SR', 'Frequency': 'DDR5-4800', 'Type(MCR)': 'DDR5',
                        'Message': '16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix', 'Size': '16GB'},
               'generate': 'DDR5',
               'channel': '0'}

        get_single_info() from spd file get target information,include.
        Example:
            page_expected_res ==> type:list ['Socket0.ChA.Dimm0: 4800MT/s Hynix SRx8 16GB RDIMM'...]
            dimm_table_expected_res ==> type:list[dict] [{'width': '16gbx8', 'vendor': 'Hynix', 'generate': 'DDR5', 'rank': 'DR', 'size': '32GB'}...]
            alphabet ==> type:list ['A'...]
    """

    mapping = {
        'Socket0': {
            'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
            'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
            'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}},
        'Socket1': {
            'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
            'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
            'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}}
    }

    def __init__(self, *args, **kwargs):
        self.log = args[0]
        self.spd_info = kwargs.get('spd')
        self.map_relation = kwargs.get('map')

    @staticmethod
    def extract_spd_info(spd_file):
        pattern = re.compile(r'\$dimms \+= .+')
        dimms = re.findall(pattern, spd_file)
        dimm_list = []
        dimm_dict = {}
        kw = ['socket', 'die', 'channel', 'slot', 'generate', 'type']

        def filter_type():
            kw_list = ['Size', 'Data width', 'Rank', 'Frequency', 'Type(MCR)', 'Vendor', 'Message']
            line = dimm_list[num][-1].split('_')
            size = line[0]
            width = '16gb%s' % line[1][2:]
            rank = line[1][:2]
            frequency = line[3] + '-' + line[2]
            form = line[3]
            vendor = line[-1]
            val = [size, width, rank, frequency, form, vendor, dimm_list[num][-1]]
            return dict(zip(kw_list, val))

        for num, dimm in enumerate(dimms):
            info = dimm.split('=')[1].strip().replace('[[', '')
            info = info.replace(']]', '')
            info = info.replace('"', '')
            info = info.replace('.txt', '')
            info = info.replace(' ', '').split(',')
            dimm_list.append(info)
            dimm_list[num].insert(-1, filter_type())
            dimm_dict['dimm%s' % num] = dict(zip(kw, info))
        return dimm_dict

    def check_dimminfo_table(self, socket, channel, slot):
        dimm_table = get_uart_dimminfo(self.log, socket)
        kw = ['vendor', 'generate', 'size', 'width', 'rank']
        val = []
        slot_info = dimm_table.get('channel%s' % channel).get('slot%s' % slot)
        try:
            vendor = slot_info[0][5:].title()
            generate = slot_info[15][:4].upper()
            size = slot_info[14][:4].upper()
            width = re.search(r'\((?P<val>\d+gb.\d)', slot_info[14]).group('val')
            rank = re.search(r'[sd]r', slot_info[14]).group().upper()
            val.extend([vendor, generate, size, width, rank])
            dimm_table_dict = dict(zip(kw, val))
            return dimm_table_dict
        except Exception as e:
            raise e

    def get_single_info(self):
        page_expected_res = []
        dimm_table_expected_res = []
        alphabet = []
        for idx, dimm in enumerate(self.spd_info):
            spd_file = self.spd_info.get(dimm)
            soc = spd_file.get('socket')
            die = spd_file.get('die')
            cha = spd_file.get('channel')
            slot = spd_file.get('slot')
            generate = spd_file.get('generate')
            vendor = spd_file.get('type').get('Vendor')
            width = spd_file.get('type').get('Data width')
            size = spd_file.get('type').get('Size')
            rank = spd_file.get('type').get('Rank')
            frequency = spd_file.get('type').get('Frequency')
            ty_mcr = spd_file.get('type').get('Type(MCR)')
            message = spd_file.get('type').get('Message').split('_')
            letter = self.map_relation.get('Socket%s' % soc).get('Die%s' % die).get(cha)
            txt_channel = string.ascii_uppercase.index(letter)
            alphabet.append(letter)
            page_expected_res.append(
                ('Socket{}.Ch{}.Dimm{}: {}MT/s {} {} {} {}'.format(soc, letter, slot, message[2],
                                                                   vendor, message[1], size,
                                                                   message[4])))
            dimm_table_dict = self.check_dimminfo_table(soc, txt_channel, slot)
            dimm_table_expected_res.append(dimm_table_dict)
        return page_expected_res, dimm_table_expected_res, alphabet


def positionlines(lines, start, end):
    start_flag = False
    start_pos = end_pos = -1
    for idx, line in enumerate(lines):
        if line.lower().startswith(start.lower()):
            start_pos = idx
            start_flag = True
            continue
        if start_flag and line.lower().startswith(end.lower()):
            end_pos = idx
            break
    if start_pos == -1 or end_pos == -1:
        raise Exception('Not found position')
    return start_pos, end_pos


def change_script(sim_script, dimm_info, delete=None):
    shutil.copy(sim_script, sim_script + '.bak')
    with open(sim_script, 'r+') as old, open('%s.zz' % sim_script, 'w+') as new:
        sim_lines = old.readlines()
        start_idx, end_idx = positionlines(sim_lines, '$script_type',
                                           'run-command-file')
        if dimm_info:
            if '$dimms' in ''.join(sim_lines):
                old_dimms = re.findall('\$dimms.*', ''.join(sim_lines))
                for i in old_dimms:
                    sim_lines.remove(i + '\n')
            if delete:
                del sim_lines[start_idx:end_idx + 1]
            sim_lines.insert(start_idx + 1, dimm_info)
        new.writelines(''.join(sim_lines))
        old.close()
        os.remove(sim_script)
        new.close()
        os.rename('%s.zz' % sim_script, sim_script)
    shutil.move(sim_script + '.bak', sim_script)


if __name__ == '__main__':
    # log_path = r'D:\\simics_uart.log' # 1 slot
    p1 = r'C:\Users\xuhuixux\Downloads\simics_uart.log'  # 2 slot
    p2 = r'C:\Test_Projects\test.txt'
    # # d0 = built_list(p1)
    # # t1 = get_tables('DIMMINFO_SYSTEM_TABLE', p1)
    # d1 = get_dimm_info(p1, 0)
    # print(d1)
    # a = a()
    # get_uart_dimminfo(p1)
    # info = a.extract_dimm_info()
    # a.check_tables_target_info(p1)
    # a.check_dimm_system_table(p1)
    # a.create_socket_info_dict(os_ret)
    # a.check_target_size_speed(os_res)

    test = MemoryInfo(p1, map=MemoryInfo.mapping, spd=MemoryInfo.extract_spd_info(dimms))
    test.extract_spd_info(dimms)
    test.get_single_info()
    # test.verify_dimmtable_info()
    # test.get_osret_handle(os_res)
    # test.verify_speed_size()
    # extract_spd_info(dimms)
    # test.get_single_info()
    # change_script(p2, dimms)
