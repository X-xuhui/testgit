# coding=utf-8
import socket
# s = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
# s.bind(('10.104.56.22',2121))
# s.sendto('你好'.decode('utf8').encode('gb2312'),('10.104.56.22',2121))
# content = s.recvfrom(1024)
# print content[0].decode('gb2312')
# s.close()
# s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
# s.bind(('10.104.56.22',2121))
# s.listen(128)
# content = s.accept()
# data = content[0].recv(1024)
# print(data.decode('utf8'))
# s.close()

# 客户端请求
client = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
client.connect(('10.104.58.44',2121))
file_name = input('请输入要下载的内容：')
client.send(file_name.encode('utf8'))
data = client.recv(1024).decode('utf8')
with open(file_name,'w',encoding='utf8') as fp:
    fp.write(data)
client.close()