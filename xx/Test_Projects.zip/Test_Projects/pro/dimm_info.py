import os
import re
import string


# def get_tables(table_name, log_path=None, line_limit=1000):
#     if not os.path.exists(log_path):
#         return False, 'simics uart not found!'
#     with open(log_path, 'r') as fp:
#         lines = fp.readlines()
#     start_flag = False
#     tables = []
#     table_line = []
#     for line in lines:
#         line = line.strip()
#         # drop oversize data
#         if len(table_line) > line_limit:
#             table_line = []
#             start_flag = False
#
#         if not start_flag:
#             if line == 'START_' + table_name:
#                 start_flag = True
#                 table_line = []
#             continue
#
#         if line == 'STOP_' + table_name:
#             tables.append(table_line)
#             start_flag = False
#             continue
#         table_line.append(line)
#
#     return tables
#
# def get_target_table_in_log(log_path):
#     log_path = log_path
#     if not os.path.exists(log_path):
#         return False, 'log path {} not found!'.format(log_path)
#     with open(log_path, 'r+') as fp:
#         lines = [line.strip() for line in fp.readlines()]
#         for head in lines:
#             s = re.search(r'START_SOCKET_0_DIMMINFO_TABLE', head)
#             if not s:
#                 continue
#             start = lines.index(s.group())
#             break
#         for end in lines:
#             e = re.search(r'STOP_SOCKET_0_DIMMINFO_TABLE', end)
#             if not e:
#                 continue
#             end = lines.index(e.group())
#             break
#         part_msg = lines[start:end]
#         new_part_msg = []
#         for i in part_msg:
#             t = re.search(r'[^=-].*', i)
#             if not t:
#                 continue
#             tackle = t.group().split('|')
#             new_part_msg.append(tackle)
#         for j in new_part_msg:
#             for k in j:
#                 h = re.search(r'Channel', k)
#                 if not h:
#                     continue
#                 head = new_part_msg.index(j)
#                 break
#         target_msg = new_part_msg[head + 1:]
#         return target_msg
#
#
# def built_list(log_path):
#     table = get_target_table_in_log(log_path)
#     total_list = {}
#     S = []
#     Channel0 = []
#     Channel1 = []
#     Channel2 = []
#     Channel3 = []
#     Channel4 = []
#     Channel5 = []
#     Channel6 = []
#     Channel7 = []
#     for i in table:
#         S.append(i[0])
#         Channel0.append(i[1])
#         Channel1.append(i[2])
#         Channel2.append(i[3])
#         Channel3.append(i[4])
#         Channel4.append(i[5])
#         Channel5.append(i[6])
#         Channel6.append(i[7])
#         Channel7.append(i[8])
#     total_list.update(
#         {'socket': S, 'Channel0': Channel0, 'Channel1': Channel1, 'Channel2': Channel2, 'Channel3': Channel3,
#          'Channel4': Channel4, 'Channel5': Channel5, 'Channel6': Channel6, 'Channel7': Channel7})
#     return total_list
#
#
# def get_dimm_info_v1(log_path, socket=0):
#     table_name = 'SOCKET_{}_DIMMINFO_TABLE'.format(socket)
#     dimm_tables = get_tables(table_name, log_path)
#     if not dimm_tables:
#         raise LookupError('{} Not Found!'.format(table_name))
#     dimm_table = dimm_tables[0]
#     slots = []
#     channel_th = []
#     channel_tr = []
#     for line in dimm_table:
#         if not channel_th:
#             m_col = re.findall(r'\|\s*(Channel *\d+)\s*', line)
#             if not m_col:
#                 continue
#             channel_th = [ch.replace(' ', '').lower() for ch in m_col]
#             continue
#         channel_num = len(channel_th)
#         m_row = re.match(r'.*(\|.*){{{}}}'.format(channel_num), line)
#         if not m_row:
#             slots.append([])
#             continue
#         vals = [i.strip() for i in line.split('|')[1:-1]]
#         if len(vals) == channel_num:
#             slots[-1].append(vals)
#
#     dimm_dict = {}
#     for id_th, ch in enumerate(channel_th):
#         dimm_dict[ch] = [tr[id_th] for tr in channel_tr]
#
#     return dimm_dict
#
#
# def get_dimm_info(log_path, socket=0):
#     table_name = 'SOCKET_{}_DIMMINFO_TABLE'.format(socket)
#     dimm_tables = get_tables(table_name, log_path)
#     if not dimm_tables:
#         raise LookupError('{} Not Found!'.format(table_name))
#     dimm_table = dimm_tables[0]
#     slots = {}
#     slot_no = 's'
#     for line in dimm_table:
#         _chs = line.split('|')
#         if not len(_chs) > 1:
#             continue
#         if _chs[0].strip():
#             slot_no = _chs[0].strip().lower()
#             slots[slot_no] = []
#         slots[slot_no].append([ch.replace(' ', '').lower() for ch in _chs[1:-1]])
#
#     channel_ths = slots.pop('s')[0]
#     dimm_dict = {}
#     for id_th, ch in enumerate(channel_ths):
#         dimm_dict[ch] = {}
#         for s_name, s_list in slots.items():
#             dimm_dict[ch]['slot' + s_name] = [tr[id_th] for tr in s_list]
#
#     return dimm_dict


dimms = """
$ddr_type = "DDR5"
$default_spd_info = "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"
$dimms = []
$dimms += [[0, 1, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
$dimms += [[1, 1, 0, 0, "DDR5", "16GB_SRx8_4800_DDR5_RDIMM_IDT_Hynix.txt"]]
"""
ret = '''Handle 0x0001, DMI
            Size : 16GB
            Speed : 4800 MT/s
            Logical Size : None
Handle 0x0002, DMI
            Size : No Module Installed
Handle 0x0011, DMI
            Size : No Module Installed
Handle 0x0012, DMI
            Size : No Module Installed
Handle 0x0013, DMI
            Size : No Module Installed
Handle 0x0019, DMI
            Size : No Module Installed
Handle 0x001A, DMI
            Size : 16GB
            Speed : 4800 MT/s
            Logical Size : None
Handle 0x001B, DMI
            Size : No Module Installed
Handle 0x0024, DMI
            Size : 64GB
            Speed : 4800 MT/s
            Logical Size : None
Handle 0x0025, DMI
            Size : No Module Installed'''

class a:
    def extract_dimm_info(self):
        self.mapping = {
            'Socket0': {
                'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
                'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
                'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}},
            'Socket1': {
                'Die0': {'0': 'C', '1': 'D', '2': 'I', '3': 'J'},
                'Die1': {'0': 'A', '1': 'B', '2': 'G', '3': 'H'},
                'Die2': {'0': 'E', '1': 'F', '2': 'K', '3': 'L'}}
        }
        position = []
        socket = []
        letter = []
        slot = []
        for dimm in dimms.split('\n'):
            m = re.search(r'\[(?P<val>\d.+ [^"DDR5"])', dimm)
            if not m:
                continue
            res = m.group('val').replace(', ', '')
            position.extend(
                [('Socket{}'.format(res[0]), 'Die{}'.format(res[1]), '{}'.format(res[2]), 'Slot{}'.format(res[3]))])
            slot.append(res[3])
        for so in position:
            socket.append(so[0])
        for idx in range(len(position)):
            letter.append(self.mapping.get(position[idx][0]).get(position[idx][1]).get(position[idx][2]))
        return letter,slot,socket

    def create_socket_info_dict(self):
        alphabet = []
        slot = []
        for i in range(1,49):
            slot.append("0x%04x" % i)
        for j in range(2):
            for l in range(ord('a'), ord('l') + 1):
                alphabet.append(chr(l) + str(j))
        alphabet.sort()
        slot0 = sorted(dict(zip(alphabet, slot[:24])).items())
        slot1 = sorted(dict(zip(alphabet, slot[24:48])).items())
        slot_set = [slot0,slot1]
        socket = {}
        socket_name = ['Socket0', 'Socket1']
        for idx in range(2):
            alphabet_dict = {}
            for al in string.ascii_uppercase[:12]:
                alphabet_dict[al] = slot_set[idx][:2]
                socket[socket_name[idx]] = alphabet_dict
                del (slot_set[idx][:2])
        return socket

    def check_target_size_speed(self,os_res):
        extract_dimm = self.extract_dimm_info()
        socket_dict = self.create_socket_info_dict()
        socket = extract_dimm[2]
        slot_num = extract_dimm[1]
        size_speed = os_res.split('\n')
        uninstall = []
        count = 0
        for un in size_speed:
            m = re.search(r'No Module Installed',un)
            if not m:
                continue
            unavailable = m.group()
            uninstall.append(unavailable)
        for idx,key in enumerate(socket):
            target_slot = dict({key:socket_dict.get(key).get(extract_dimm[0][idx])})
            m = re.search(r'0x[a-fA-F0-9]+', target_slot.get(key)[int(slot_num[idx])][1])
            if not m:
                continue
            res = m.group()
            for start in size_speed:
                s = re.search('0x'+'{}'.format(hex(int(res,16))).replace('0x','').upper().zfill(4), start)
                if not s:
                    continue
                start_idx = size_speed.index(start)
                for end in size_speed:
                    e = re.search('0x'+'{}'.format(hex(int(res,16)+1)).replace('0x','').upper().zfill(4), end)
                    if not e:
                        continue
                    end_idx = size_speed.index(end)
                    target_info = size_speed[start_idx :end_idx]
                    # log2all(target_info)
                    print target_info
                    count += 1
                    break
                break
            if len(uninstall) + count == 10:
                print 2
            # else:
            #     self.count += 1

    def check_memory_topology(self):
        page = ['Socket0.ChA.Dimm0: 4800MT/s Hynix SRx8 16GB RDIMM','Socket1.ChA.Dimm0: 4800MT/s Hynix SRx8 16GB RDIMM']
        dimm_info = self.extract_dimm_info()
        Socket = dimm_info[2]
        letter = dimm_info[0]
        Slot = dimm_info[1]
        for idx,v in enumerate(page):
            expected_dimm_info = '{}.Ch{}.Dimm{}: 4800MT/s Hynix SRx8 16GB RDIMM'.format(Socket[idx],letter[idx],Slot[idx])
            if expected_dimm_info in page:
                print 2
            #     log2all(expected_dimm_info)
            # else:
            #     self.count += 1

if __name__ == '__main__':
    # log_path = r'D:\\simics_uart.log' # 1 slot
    # p1 = r'C:\Users\xuhuixux\Downloads\simics_uart.log' # 2 slot
    # # d0 = built_list(p1)
    # # t1 = get_tables('DIMMINFO_SYSTEM_TABLE', p1)
    # d1 = get_dimm_info(p1, 0)
    # print(d1)
    a = a()
    # info = a.extract_dimm_info()
    # # a.create_slot_info_dict(info[1])
    # a.check_target_size_speed(ret)
    a.check_memory_topology()